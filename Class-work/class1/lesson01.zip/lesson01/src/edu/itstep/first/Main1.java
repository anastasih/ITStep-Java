package edu.itstep.first;

public class Main1 {
    public static void main(String[] args) {
        //byte short int long
        //ctrl + alt + L
        int age = 18;
        byte b1, b2;
        b1 = 127;

        //double float
        final double PI;
        PI = 3.14;
        System.out.println(PI);

        //char
        char ch = '*';

        //boolean
        boolean isMarried = true;
        System.out.println(isMarried);
    }
}
