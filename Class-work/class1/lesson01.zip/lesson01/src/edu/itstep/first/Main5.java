package edu.itstep.first;

public class Main5 {
    public static void main(String[] args) {
        //if
        int money = 1000;
        int price = 500;
        if (money >= price) {
            System.out.println("Покупка доступна");
        } else {
            System.out.println("Не хватает денег");
        }
    }
}
