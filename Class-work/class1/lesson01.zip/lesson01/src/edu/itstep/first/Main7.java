package edu.itstep.first;

public class Main7 {
    public static void main(String[] args) {
        // && || !
//        System.out.println(3 > 1 || 2 == 2);
        //System.out.println("hello" && "");

//        int count = 1;
//        int a = 1;
//        int b = 2;
//        if (a == b && count > 10) {
//            System.out.println("work");
//        }
//        count++;
//        System.out.println(count);

//        boolean isFinished = true;
//        System.out.println(!isFinished);
//
//        if (isFinished != true) {
//            System.out.println("workd");
//        }
    }
}
