package edu.itstep.first;

public class Main {
    //psvm
    public static void main(String[] args) {
        //sout
        System.out.println("Hello World!!!");
    }
}
