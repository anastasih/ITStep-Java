package edu.itstep.first;

public class Main0 {
    public static void main(String[] args) {
        //CTRL + d
        //CTRL + /
        //CTRL + SHIFT + /
        System.out.println("Привет Мир");
        System.out.println("Привет Мир");
        System.out.println("Привет Мир");
        System.out.println("Привет Мир");
        System.out.println("Привет Мир");
        System.out.println("Привет Мир");
        System.out.println("Привет Мир");
        System.out.println("Привет Мир");
    }
}
