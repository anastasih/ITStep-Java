package edu.itstep.first;

public class Main8 {
    public static void main(String[] args) {
        //String
//        String word1 = "Hello";
//        String word2 = "Hello";
//        System.out.println(word1 == word2);
//        System.out.println(word1.equals(word2));
    }
}
