package edu.itstep.first;

public class Main2 {
    public static void main(String[] args) {
        //преобразование типов
//        byte b = 127;
//        int i = b;

//        int i = 129;
//        byte b = (byte) i;
//        System.out.println(b);

        char ch1 = 'a';
        char ch2 = 'b';
        System.out.println((int) ch1);
        System.out.println((int) ch2);
        System.out.println(ch1 - ch2);

    }
}
