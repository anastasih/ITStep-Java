package edu.itstep.first;

public class Main3 {
    public static void main(String[] args) {
        // + - / * %
        //System.out.println(127 % 10);
        //System.out.println(5^2);


    }
}
