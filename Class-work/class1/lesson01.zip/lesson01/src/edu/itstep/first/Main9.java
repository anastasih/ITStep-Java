package edu.itstep.first;

public class Main9 {
    public static void main(String[] args) {
        //циклы
        //fori
//        for (int i = 0; i < 5; i++) {
//            System.out.println("Hello");
//        }

//        int count = 1;
//        while (count <= 3) {
//            System.out.println("work");
//            count++;
//        }

        //continue break


    }
}
