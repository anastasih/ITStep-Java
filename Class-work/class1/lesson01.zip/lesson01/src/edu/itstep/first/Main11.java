package edu.itstep.first;

public class Main11 {
    public static void main(String[] args) {
        int size = 5;
        int[] arr = new int[size];
        System.out.println(arr);
        System.out.println(arr[0]);
        System.out.println(arr.length);

    }
}
