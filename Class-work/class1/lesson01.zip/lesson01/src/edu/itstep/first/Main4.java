package edu.itstep.first;

public class Main4 {
    public static void main(String[] args) {
        //> < >= <= != ==
        System.out.println(3 >= 3);
        System.out.println('a' > 'b');
        //System.out.println("hello" > "abc");
    }
}
